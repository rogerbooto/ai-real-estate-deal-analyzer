# src/core/utils/serialize.py
from __future__ import annotations
from dataclasses import is_dataclass, asdict
from pathlib import Path
from typing import Any

try:
    # pydantic v2
    from pydantic import BaseModel  # type: ignore
    _PydanticBase = BaseModel
except Exception:  # pragma: no cover
    _PydanticBase = object  # type: ignore

def to_primitive(x: Any) -> Any:
    # Pydantic v2
    if isinstance(x, _PydanticBase):  # type: ignore
        try:
            return x.model_dump()
        except Exception:
            try:
                return x.dict()
            except Exception:
                pass
    # Dataclass
    if is_dataclass(x):
        return asdict(x)
    # Mapping / list / tuple recursion
    if isinstance(x, dict):
        return {k: to_primitive(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        t = [to_primitive(v) for v in x]
        return t if isinstance(x, list) else tuple(t)
    return x

# src/core/ingest/__init__.py

from pathlib import Path
from .listing_ingest import ingest_listing

def _discover_listing_file(deal_dir: Path) -> Path | None:
    for pat in ("listing.txt", "listing.md", "listing.html"):
        p = deal_dir / pat
        if p.exists():
            return p
    for ext in ("*.txt", "*.md", "*.html"):
        for p in deal_dir.glob(ext):
            if p.is_file():
                return p
    return None

def run_ingest(*, url: str | None = None, file: Path | None = None, photos_dir: Path | None = None, **kwargs):
    # NEW: allow file to be a directory bundle
    if file and isinstance(file, Path) and file.is_dir():
        deal_dir = file
        file = _discover_listing_file(deal_dir)
        pd = deal_dir / "photos"
        photos_dir = photos_dir or (pd if pd.exists() else None)
    return ingest_listing(url=url, file=file, photos_dir=photos_dir, **kwargs)

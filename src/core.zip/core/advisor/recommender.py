# src/core/advisor/recommender.py
from __future__ import annotations

from typing import TYPE_CHECKING, Any, Iterable, List, Tuple

if TYPE_CHECKING:
    # Type-only import to avoid runtime circular dependency
    from src.core.intelligence.deal_fusion import DealIntelligence  # noqa: F401


def rank_deals(deals: Iterable[Any]) -> List[Tuple[Any, float]]:
    """
    Rank deals by their composite score (duck-typed).
    We don't import DealIntelligence at runtime to avoid circular imports.
    """
    scored: List[Tuple[Any, float]] = []
    for d in deals:
        # Prefer 'composite_score'; fall back to 'score'; else 0.0
        score = getattr(d, "composite_score", None)
        if score is None:
            score = getattr(d, "score", 0.0)
        scored.append((d, float(score)))
    scored.sort(key=lambda x: x[1], reverse=True)
    return scored
